package module.CalendarAppointments;
import javax.swing.JButton;

   public class DisabledJButton extends JButton{
	private static final long serialVersionUID = 1L;

	public DisabledJButton(){
          setEnabled(false);
      }
  }