package framework;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;

import module.CalendarAppointments.AnalogClock;

/** GPSIS
 * Initial loading Class.
 * 
 * TODO
 * Finish 
 * 
 * @author Vijendra Patel
 */

public class GPSIS {
	
	/** main
	 * Where the application will start.
	 */
	
	public static AnalogClock clock;
	
	public static void main(String[] args)
	{
		GPSISFramework GPSIS = new GPSISFramework();		
		GPSIS.initialise();		
		
		
//        clock = new AnalogClock();
//        Thread analogClockThread = new Thread(clock);
//        analogClockThread.setDaemon(true);
//        analogClockThread.start();
		
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                clock = new AnalogClock();
            }
        });
		
	}
}

/**
 * End of File: GPSIS.java
 * Location: gpsis/framework
 */