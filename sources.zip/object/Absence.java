package object;

import framework.GPSISObject;

public class Absence extends GPSISObject {

}
