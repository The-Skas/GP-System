package object;

import framework.GPSISObject;

public class Role extends GPSISObject {

}
